import { Game } from "./gameHandler.js";

export const game = new Game();
game.startGame();
