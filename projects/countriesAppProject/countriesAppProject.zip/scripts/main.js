// import { getCountries } from "./countries.js";
import { createCardList } from "./domBuilder.js";

// await getCountries();
createCardList();